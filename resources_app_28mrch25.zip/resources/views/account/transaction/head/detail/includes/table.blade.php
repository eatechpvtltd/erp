<div class="row">
    @include($view_path.'.detail.includes.table-data')
</div>
